
First of all ... the credits to James's excellent work

/*
 *
 * Copyright (C) James Fidell 1994-2002.
 *
 * Permission to use, copy, modify and distribute this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear in
 * supporting documentation, and that the name of the copyright holder
 * not be used in advertising or publicity pertaining to distribution
 * of the software without specific, written prior permission. The
 * copyright holder makes no representations about the suitability of
 * this software for any purpose. It is provided "as is" without express
 * or implied warranty.
 *
 * THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS, IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
 * CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */


Full details on the emulator, docs, setting etc
are available at or linked from:

	 http://www.cloud9.co.uk/james/BBCMicro/Xbeeb/


In this package:

	- readme.txt	 : this file
	- xbeeb				 : the executable
	- /fonts-xbeeb : fonts required by xbeeb
	- /rom-patcher : the original BBC rom OS-1.2.rom needs to be patched using this tool
	- /roms				 : the filesystem rom xdfs0.90.rom, the other two (BASIC2.rom & OS-1.2.rom can be easily googled).

Set-Up:

1.Prepare

 1a. Unpack into a [some-path]/xbeeb directory 
 1b. Get the required roms from the web 
     (not sure i was allowed to include those, as original didn't)
	BASIC2.rom
	OS-1.2.rom

2. Patch the ROM
 2a. Copy the OS-1.2.rom into [some-path]/xbeeb/rom-patcher/ directory
 2b. Rename the file OS1.2p1.rom
 2c. Run ./pch, which will apply the required patch to file: OS1.2p1.rom
 2d. Copy the patched version into [some-path]/xbeeb/roms
 2e. Copy the BASIC2.rom into the [some-path]/xbeeb/roms directory too (should be 3 files in total in there now)

3. Install the required fonts (within X, not SSH)

 3a. Copy directory [some-path]/xbeeb/fonts-xbeeb into /etc/
 3b. Follow the original instructions:
  	$ mkfontdir /etc/fonts-xbeeb
	$ xset fp+ /etc/fonts-xbeeb
	$ xset fp rehash

4. Try It!

 4a. Go to your [some-path]/xbeeb directory and run ./xbeeb from with X.


I had to make some minor changes to make it build, these are my notes
as i went along:

	- used makefile.v
	- change VideoUla.c/h to resolve compile issue. (comment out the extern in the Header file)
	- update the makefile.v to include InfFS.c
	- add -lXext to the link line to resove externals like : XShmDetach et al...
	- comment out:  #define		FASTHOST from the config.h .. (makes all the difference to speed!)

Think there are some sample "disks" floating around, but haven't looked
at those yet, wanted to share this first.

..>> Vince Singleton.

Created: 11/7/2012
Last Updated: 11/7/2012